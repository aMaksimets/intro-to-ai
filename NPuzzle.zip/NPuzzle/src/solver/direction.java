package solver;

public enum direction {
	Up,
	Down,
	Left,
	Right
};
